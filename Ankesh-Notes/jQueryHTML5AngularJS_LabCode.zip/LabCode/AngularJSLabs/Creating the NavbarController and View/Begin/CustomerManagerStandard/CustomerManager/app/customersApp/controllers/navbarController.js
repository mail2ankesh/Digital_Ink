﻿(function () {

    var injectParams = ['$scope', '$location', 'config', 'authService'];

    var NavbarController = function ($scope, $location, config, authService) {
        

        

    };

    NavbarController.$inject = injectParams;

    angular.module('customersApp').controller('NavbarController', NavbarController);

}());
