﻿(function () {

    var injectParams = ['$scope'];

    var AboutController = function ($scope) {

    };

    AboutController.$inject = injectParams;

    angular.module('customersApp').controller('AboutController', AboutController);

}());