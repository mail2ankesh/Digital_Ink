'use strict';

module.exports = [
  { start: { date: new Date(2014, 2, 5), value: 3 }, end: { date: new Date(2014, 2, 7), value: 5 } }
];