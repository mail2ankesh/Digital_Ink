'use strict';

module.exports = [
  { date: new Date(2014, 2, 5), value: 14.81 },
  { date: new Date(2014, 2, 6), value: 14.98 },
  { date: new Date(2014, 2, 7), value: 15.54 }
];