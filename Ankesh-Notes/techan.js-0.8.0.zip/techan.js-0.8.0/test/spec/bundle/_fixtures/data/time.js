module.exports = {
  intraday: [
    new Date(0),
    new Date(1000),
    new Date(2000),
    new Date(3000),
    new Date(4000),
    new Date(5000),
    new Date(6000),
    new Date(7000),
    new Date(8000),
    new Date(9000)
  ]
};