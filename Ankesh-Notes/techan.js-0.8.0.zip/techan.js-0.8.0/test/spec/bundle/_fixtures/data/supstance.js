'use strict';

module.exports = [
  { start: new Date(1), end: new Date(2), value: 8 }
];