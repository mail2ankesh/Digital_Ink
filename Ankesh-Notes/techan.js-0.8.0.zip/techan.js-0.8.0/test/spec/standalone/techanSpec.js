describe('Given I have the standalone bundle "techan" available', function() {
  'use strict';

  describe('When I attempt to use it via global scope', techanSpec(techan));
});